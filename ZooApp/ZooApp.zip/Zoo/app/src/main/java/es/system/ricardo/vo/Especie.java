package es.system.ricardo.vo;

import android.content.ContentValues;

import java.util.Objects;

import es.system.ricardo.modelo.contract.EspecieContract;

public class Especie {
    private String nombreVulgar;
    private String nombreCientifico;
    private String familia;
    private boolean peligroExtincion;

    /**
     * Constructor por defecto de la clase Especie
     */
    public Especie() {
    }

    /**
     * Constructor de la clase Especie
     * @param nombreVulgar de la Especie
     * @param nombreCientifico de la Especie
     * @param familia de la Especie
     * @param peligroExtincion de la Especie
     */
    public Especie(String nombreVulgar, String nombreCientifico, String familia, boolean peligroExtincion) {
        this.nombreVulgar = nombreVulgar;
        this.nombreCientifico = nombreCientifico;
        this.familia = familia;
        this.peligroExtincion = peligroExtincion;
    }

    public String getNombreVulgar() {
        return nombreVulgar;
    }

    public void setNombreVulgar(String nombreVulgar) {
        this.nombreVulgar = nombreVulgar;
    }

    public String getNombreCientifico() {
        return nombreCientifico;
    }

    public void setNombreCientifico(String nombreCientifico) {
        this.nombreCientifico = nombreCientifico;
    }

    public String getFamilia() {
        return familia;
    }

    public void setFamilia(String familia) {
        this.familia = familia;
    }

    public boolean isPeligroExtincion() {
        return peligroExtincion;
    }

    public void setPeligroExtincion(boolean peligroExtincion) {
        this.peligroExtincion = peligroExtincion;
    }

    public ContentValues toContentValues() {
        android.content.ContentValues values = new ContentValues();
        values.put(EspecieContract.EspecieEntry.nombreVulgar, nombreVulgar);
        values.put(EspecieContract.EspecieEntry.nombreCientifico, nombreCientifico);
        values.put(EspecieContract.EspecieEntry.familia, familia);
        values.put(EspecieContract.EspecieEntry.peligroExtincion, peligroExtincion);
        return values;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Especie especie = (Especie) o;
        return Objects.equals(nombreVulgar, especie.nombreVulgar)
                && Objects.equals(nombreCientifico, especie.nombreCientifico)
                && Objects.equals(familia, especie.familia)
                && Objects.equals(peligroExtincion, especie.peligroExtincion);
    }
}
