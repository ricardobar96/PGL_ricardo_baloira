package es.system.ricardo.activity.zoo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.system.ricardo.R;

public class PantallaBuscarZoo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_buscar_zoo);
    }

    public void retroceder(View view) {
        Intent retroceder = new Intent(PantallaBuscarZoo.this,
                PantallaZoo.class);
        startActivity(retroceder);
    }
}