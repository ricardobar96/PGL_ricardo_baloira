package es.system.ricardo.modelo.contract;

import android.provider.BaseColumns;

public class ZooContract {
    public static abstract class ZooEntry implements BaseColumns {
        public static final String nombreTabla ="zoo";
        public static final String nombre ="nombre";
        public static final String ciudad ="ciudad";
        public static final String pais = "pais";
        public static final String tamanio = "tamanio";
        public static final String presupuestoAnual ="presupuestoAnual";
    }
}
