package es.system.ricardo.vo;

import android.content.ContentValues;

import java.util.Objects;

import es.system.ricardo.modelo.contract.ZooContract;

public class Zoo {
    private String nombre;
    private String ciudad;
    private String pais;
    private double tamanio;
    private double presupuestoAnual;

    /**
     * Constructor por defecto de la clase Zoo
     */
    public Zoo() {
    }

    /**
     * Constructor de la clase Zoo
     * @param nombre del Zoo
     * @param ciudad del Zoo
     * @param pais del Zoo
     * @param tamanio del Zoo
     * @param presupuestoAnual del Zoo
     */
    public Zoo(String nombre, String ciudad, String pais, double tamanio, double presupuestoAnual) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.pais = pais;
        this.tamanio = tamanio;
        this.presupuestoAnual = presupuestoAnual;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public double getTamanio() {
        return tamanio;
    }

    public void setTamanio(double tamanio) {
        this.tamanio = tamanio;
    }

    public double getPresupuestoAnual() {
        return presupuestoAnual;
    }

    public void setPresupuestoAnual(double presupuestoAnual) {
        this.presupuestoAnual = presupuestoAnual;
    }

    public ContentValues toContentValues() {
        android.content.ContentValues values = new ContentValues();
        values.put(ZooContract.ZooEntry.nombre, nombre);
        values.put(ZooContract.ZooEntry.ciudad, ciudad);
        values.put(ZooContract.ZooEntry.pais, pais);
        values.put(ZooContract.ZooEntry.tamanio, tamanio);
        values.put(ZooContract.ZooEntry.presupuestoAnual, presupuestoAnual);
        return values;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Zoo zoo = (Zoo) o;
        return Objects.equals(nombre, zoo.nombre)
                && Objects.equals(ciudad, zoo.ciudad)
                && Objects.equals(pais, zoo.pais)
                && Objects.equals(tamanio, zoo.tamanio)
                && Objects.equals(presupuestoAnual, zoo.presupuestoAnual);
    }
}
