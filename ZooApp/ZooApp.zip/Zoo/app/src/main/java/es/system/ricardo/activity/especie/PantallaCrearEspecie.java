package es.system.ricardo.activity.especie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.system.ricardo.R;

public class PantallaCrearEspecie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_crear_especie);
    }

    public void retroceder(View view) {
        Intent retroceder = new Intent(PantallaCrearEspecie.this,
                PantallaEspecie.class);
        startActivity(retroceder);
    }
}