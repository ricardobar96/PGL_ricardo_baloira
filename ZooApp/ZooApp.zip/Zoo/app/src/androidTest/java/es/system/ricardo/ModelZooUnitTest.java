package es.system.ricardo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import es.system.ricardo.vo.Zoo;

public class ModelZooUnitTest extends ComunUtilsTest{
    Zoo zoo;

    @Before
    public void before(){
        zoo = new Zoo("Jurassic Park", "Paris", "Francia", 10000,
                2000000000);
    }

    @Test
    public void findZooTest(){
        Zoo zooFind = zoosDbHelper.getById(zoo.getNombre());
        assertNotNull("El zoo encontrado es null", zooFind);
        assertEquals("El objeto almacenado y encontrado no son iguales",zooFind, zoo);
    }

    @Test
    public void findZoosTest(){
        List<Zoo> zoos = zoosDbHelper.getAll();
        assertNotNull("El numero de zoos encontrado es menor de 1", zoos.size() < 1);
        assertEquals("El objeto almacenado y encontrado no son iguales",zoos.get(0), zoo);
    }

    @Test
    public void saveZooTest(){
        assertNotNull("El zoo se ha agregado con exito a la tabla",
                zoosDbHelper.save(zoo));
    }

    @Test
    public void deleteZooTest(){
        int resultado = zoosDbHelper.delete(zoo.getNombre());
        assertTrue(resultado == 1);
    }

    @Test
    public void updateZooTest(){
        assertNotEquals("El zoo se ha actualizado con exito",
                zoo, zoosDbHelper.update(zoo, zoo.getNombre()));
    }
}