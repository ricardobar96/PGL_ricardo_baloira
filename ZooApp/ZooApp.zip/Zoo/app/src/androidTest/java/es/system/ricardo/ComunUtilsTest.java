package es.system.ricardo;

import static org.junit.Assert.fail;

import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Before;
import org.junit.BeforeClass;

import es.system.ricardo.modelo.helper.AnimalDbHelper;
import es.system.ricardo.modelo.helper.EspecieDbHelper;
import es.system.ricardo.modelo.helper.ZooDbHelper;
import es.system.ricardo.vo.Animal;
import es.system.ricardo.vo.Especie;
import es.system.ricardo.vo.Zoo;

public class ComunUtilsTest {

    static Context appContext = null;

    static Zoo zoo = null;
    static ZooDbHelper zoosDbHelper;

    static Animal animal = null;
    static AnimalDbHelper animalesDbHelper;

    static Especie especie = null;
    static EspecieDbHelper especiesDbHelper;

    @Before
    public void beforeClass() {
        try {
            appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

            zoosDbHelper = new ZooDbHelper(appContext);
            zoo = new Zoo("Loro Parque Tenerife", "Puerto de la Cruz", "Espania", 1400, 1000000000);
            zoosDbHelper.save(zoo);

            animalesDbHelper = new AnimalDbHelper(appContext);
            animal = new Animal(1, "Hembra", 2006, "Portugal", "Europa");
            animalesDbHelper.save(animal);

            especiesDbHelper = new EspecieDbHelper(appContext);
            especie = new Especie("Avestruz", "Struthio camelus", "Aves", false);
            especiesDbHelper.save(especie);

        }catch (Exception ex) {
            fail("Se ha producido un error creando el elemento:"+ex.getMessage());
        }
    }

}
