package es.system.ricardo.modelo.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterZoo extends RecyclerView.Adapter<AdapterZoo.HolderZoo> {

    String nombres1[], descripcion2[];

    public AdapterZoo(Context context, String nombres[], String descripcion[], int imagenes[]){
        context = context;
    }

    @NonNull
    @Override
    public HolderZoo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull HolderZoo holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class HolderZoo extends RecyclerView.ViewHolder{
        public HolderZoo(@NonNull View itemView) {
            super(itemView);
        }
    }
}
