package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import es.system.ricardo.R;

public class PantallaAnimal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_animal);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_animal, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.menuCrearAnimal:
                Intent pantallaCrearAnimal =
                        new Intent(PantallaAnimal.this,
                        PantallaCrearAnimal.class);
                startActivity(pantallaCrearAnimal);
                break;
            case R.id.menuBuscarAnimal:
                Intent pantallaBuscarAnimal =
                        new Intent(PantallaAnimal.this,
                        PantallaBuscarAnimal.class);
                startActivity(pantallaBuscarAnimal);
                break;
            case R.id.menuModificarAnimal:
                Intent pantallaModificarAnimal =
                        new Intent(PantallaAnimal.this,
                        PantallaModificarAnimal.class);
                startActivity(pantallaModificarAnimal);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaAnimal.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}