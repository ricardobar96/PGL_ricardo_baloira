package es.system.ricardo.activity.recycler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import es.system.ricardo.R;

public class AddZoo extends AppCompatActivity {

    EditText nombre_input, pais_input, ciudad_input, tamanio_input, presupuestoAnual_input;
    Button botonAddZoo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_zoo);

        //nombre_input = findViewById(R.id.nombre_input);
    }
}