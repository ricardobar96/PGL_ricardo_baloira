package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.system.ricardo.R;

public class PantallaCrearAnimal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_crear_animal);
    }

    public void retroceder(View view) {
        Intent retroceder = new Intent(PantallaCrearAnimal.this,
                PantallaAnimal.class);
        startActivity(retroceder);
    }
}