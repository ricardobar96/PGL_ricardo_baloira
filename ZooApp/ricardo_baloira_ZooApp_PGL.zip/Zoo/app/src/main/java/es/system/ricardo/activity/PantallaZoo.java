package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

import es.system.ricardo.R;
import es.system.ricardo.modelo.helper.ZooDbHelper;

public class PantallaZoo extends AppCompatActivity {
    /*
    String nombres[], descripcion[];
    int imagenes[] = {R.drawable.ic_animal};

    RecyclerView recyclerView;
    ZooDbHelper zooDbHelper;
    ArrayList<String> zoo_nombre, zoo_ciudad, zoo_pais, zoo_tamanio, zoo_presupuestoAnual;
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_zoo);

        /*
        recyclerView = findViewById(R.id.rec);
        zooDbHelper = new ZooDbHelper(PantallaZoo.this);
        zoo_nombre = new ArrayList<>();
        zoo_ciudad = new ArrayList<>();
        zoo_pais = new ArrayList<>();
        zoo_tamanio = new ArrayList<>();
        zoo_presupuestoAnual = new ArrayList<>();
        */
    }

    /*
    void mostrarZoo(){
        Cursor cursor = zooDbHelper.readAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No hay datos de zoos", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                zoo_nombre.add(cursor.getString(0));
                zoo_ciudad.add(cursor.getString(0));
                zoo_pais.add(cursor.getString(0));
                zoo_tamanio.add(cursor.getString(0));
                zoo_presupuestoAnual.add(cursor.getString(0));

                guardarDatos();
            }
        }
    }

    void guardarDatos(){

    }
    */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_zoo, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.menuCrearZoo:
                Intent pantallaCrearZoo =
                        new Intent(PantallaZoo.this,
                        PantallaCrearZoo.class);
                startActivity(pantallaCrearZoo);
                break;
            case R.id.menuBuscarZoo:
                Intent pantallaBuscarZoo =
                        new Intent(PantallaZoo.this,
                                PantallaBuscarZoo.class);
                startActivity(pantallaBuscarZoo);
                break;
            case R.id.menuModificarZoo:
                Intent pantallaModificarZoo =
                        new Intent(PantallaZoo.this,
                        PantallaModificarZoo.class);
                startActivity(pantallaModificarZoo);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaZoo.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}