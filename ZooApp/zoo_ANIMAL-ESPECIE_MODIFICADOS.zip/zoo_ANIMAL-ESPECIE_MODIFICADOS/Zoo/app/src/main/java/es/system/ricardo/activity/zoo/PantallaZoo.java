package es.system.ricardo.activity.zoo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;

import es.system.ricardo.R;
import es.system.ricardo.activity.MainActivity;
import es.system.ricardo.vo.Zoo;

public class PantallaZoo extends AppCompatActivity {
    private ListView listviewZoo;
    private ArrayList<Zoo> zoos;
    private ArrayList<String> strZoos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_zoo);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_zoo, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.menuCrearZoo:
                Intent pantallaCrearZoo =
                        new Intent(PantallaZoo.this,
                        PantallaCrearZoo.class);
                startActivity(pantallaCrearZoo);
                break;
            case R.id.menuBuscarZoo:
                Intent pantallaBuscarZoo =
                        new Intent(PantallaZoo.this,
                                PantallaBuscarZoo.class);
                startActivity(pantallaBuscarZoo);
                break;
            case R.id.menuModificarZoo:
                Intent pantallaModificarZoo =
                        new Intent(PantallaZoo.this,
                        PantallaModificarZoo.class);
                startActivity(pantallaModificarZoo);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaZoo.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}