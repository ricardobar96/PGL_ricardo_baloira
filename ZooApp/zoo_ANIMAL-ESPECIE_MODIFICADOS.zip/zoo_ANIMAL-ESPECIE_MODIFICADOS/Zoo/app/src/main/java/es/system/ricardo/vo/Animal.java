package es.system.ricardo.vo;

import android.content.ContentValues;

import java.util.Objects;

import es.system.ricardo.modelo.contract.AnimalContract;

public class Animal {
    private int id;
    private int idEspecie;
    private String sexo;
    private int anioNacimiento;
    private String pais;
    private String continente;

    /**
     * Constructor por defecto de la clase Animal
     */
    public Animal() {
    }

    /**
     * Constructor de la clase Animal
     * @param id del Animal
     * @param idEspecie del Animal
     * @param sexo del Animal
     * @param anioNacimiento del Animal
     * @param pais del Animal
     * @param continente del Animal
     */
    public Animal(int id, int idEspecie, String sexo, int anioNacimiento, String pais, String continente) {
        this.id = id;
        this.idEspecie = idEspecie;
        this.sexo = sexo;
        this.anioNacimiento = anioNacimiento;
        this.pais = pais;
        this.continente = continente;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getIdEspecie() {
        return idEspecie;
    }

    public void setIdEspecie(int idEspecie) {
        this.idEspecie = idEspecie;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getAnioNacimiento() {
        return anioNacimiento;
    }

    public void setAnioNacimiento(int anioNacimiento) {
        this.anioNacimiento = anioNacimiento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getContinente() {
        return continente;
    }

    public void setContinente(String continente) {
        this.continente = continente;
    }

    public ContentValues toContentValues() {
        android.content.ContentValues values = new ContentValues();
        values.put(AnimalContract.AnimalEntry.idEspecie, idEspecie);
        values.put(AnimalContract.AnimalEntry.sexo, sexo);
        values.put(AnimalContract.AnimalEntry.anioNacimiento, anioNacimiento);
        values.put(AnimalContract.AnimalEntry.pais, pais);
        values.put(AnimalContract.AnimalEntry.continente, continente);
        return values;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Animal animal = (Animal) o;
        return Objects.equals(idEspecie, animal.idEspecie)
                 && Objects.equals(sexo, animal.sexo)
                 && Objects.equals(anioNacimiento, animal.anioNacimiento)
                 && Objects.equals(pais, animal.pais)
                 && Objects.equals(continente, animal.continente);
    }
}
