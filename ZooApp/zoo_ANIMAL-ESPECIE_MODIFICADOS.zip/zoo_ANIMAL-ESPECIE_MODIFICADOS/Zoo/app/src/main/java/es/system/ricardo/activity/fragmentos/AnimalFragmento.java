package es.system.ricardo.activity.fragmentos;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import es.system.ricardo.R;
import es.system.ricardo.modelo.helper.AnimalDbHelper;
import es.system.ricardo.vo.Animal;
import es.system.ricardo.vo.Especie;
import es.system.ricardo.vo.Zoo;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AnimalFragmento#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AnimalFragmento extends Fragment {
    private ListView listview;
    private ArrayList<Integer> names;
    private List<Animal> animales;
    View root;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AnimalFragmento() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AnimalFragmento.
     */
    // TODO: Rename and change types and number of parameters
    public static AnimalFragmento newInstance(String param1, String param2) {
        AnimalFragmento fragment = new AnimalFragmento();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_animal_fragmento, container, false);
        listview = (ListView) root.findViewById(R.id.idListaAnimal);

        names = new ArrayList<Integer>();
        //animales = new ArrayList<Animal>();

        Animal animal = new Animal(13, 1, "Macho", 1999, "China",
                "Asia");
        Animal animal2 = new Animal(2, 2, "Macho", 2001, "India",
                "Asia");

        AnimalDbHelper adb = new AnimalDbHelper(this.getContext());
        adb.save(animal);
        adb.save(animal2);

        //animales.add(animal);
        //animales.add(animal2);

        animales = adb.getAll();

        for(Animal a: animales){
            names.add(a.getId());
        }

        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(root.getContext(),
                android.R.layout.simple_list_item_1, names);

        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Animal a = animales.get(position);
                adb.delete(position);
                Toast.makeText(AnimalFragmento.this.getContext(), "Animal borrado: "
                        + position, Toast.LENGTH_SHORT).show();
            }
        });
        return root;
    }
}