package es.system.ricardo.activity.fragmentos;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import es.system.ricardo.R;
import es.system.ricardo.modelo.helper.EspecieDbHelper;
import es.system.ricardo.vo.Animal;
import es.system.ricardo.vo.Especie;
import es.system.ricardo.vo.Zoo;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EspecieFragmento#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EspecieFragmento extends Fragment {
    private ListView listview;
    private ArrayList<String> names;
    private ArrayList<Especie> especies;
    View root;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public EspecieFragmento() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EspecieFragmento.
     */
    // TODO: Rename and change types and number of parameters
    public static EspecieFragmento newInstance(String param1, String param2) {
        EspecieFragmento fragment = new EspecieFragmento();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        root = inflater.inflate(R.layout.fragment_especie_fragmento, container, false);
        listview = (ListView) root.findViewById(R.id.idListaEspecie);

        names = new ArrayList<String>();

        Especie especie = new Especie(2, "Ballena", "Ballenus",
                "Mamiferos", false);
        Especie especie2 = new Especie(1, "Oso panda", "Osos Pandus",
                "Mamiferos", true);

        EspecieDbHelper edb = new EspecieDbHelper((this.getContext()));
        especies = new ArrayList<Especie>();
        //especies = especieDbHelper.getAll();

        especies.add(especie);
        especies.add(especie2);

        for(Especie e: especies){
            names.add(e.getNombreVulgar());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(root.getContext(),
                android.R.layout.simple_list_item_1, names);

        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Especie e = especies.get(position);
                edb.delete(position);
                Toast.makeText(EspecieFragmento.this.getContext(), "Especie borrada: "
                                + e.getNombreVulgar(), Toast.LENGTH_SHORT).show();
            }
        });
        return root;
    }
}