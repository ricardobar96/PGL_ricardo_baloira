package es.system.ricardo.activity.zoo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import es.system.ricardo.R;
import es.system.ricardo.modelo.helper.ZooDbHelper;
import es.system.ricardo.vo.Zoo;

public class PantallaCrearZoo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_crear_zoo);
    }

    public void retroceder(View view) {
        Intent retroceder = new Intent(PantallaCrearZoo.this,
                PantallaZoo.class);
        startActivity(retroceder);
    }

    public void crearZoo(View view){
        try{
            String nombre = findViewById(R.id.idNombreZooIntro).toString();
            String ciudad = findViewById(R.id.idCiudadZooIntro).toString();
            String pais = findViewById(R.id.idPaisZooIntro).toString();
            String tamanio = findViewById(R.id.idTamanioIntro).toString();
            String presupuesto = findViewById(R.id.idPresupuestoIntro).toString();

            //double tamanioD = Double.parseDouble(tamanio);
            //double presupuestoD = Double.parseDouble(presupuesto);

            Zoo zoo = new Zoo(nombre, ciudad, pais, 1234, 1234);

            ZooDbHelper zdb = new ZooDbHelper(view.getContext());
            zdb.save(zoo);
            Toast.makeText(PantallaCrearZoo.this, "Zoo creado con éxito", Toast.LENGTH_SHORT).show();
        }
        catch(Exception ex){
            Toast.makeText(PantallaCrearZoo.this, "Ha ocurrido un error", Toast.LENGTH_SHORT).show();
        }

    }
}