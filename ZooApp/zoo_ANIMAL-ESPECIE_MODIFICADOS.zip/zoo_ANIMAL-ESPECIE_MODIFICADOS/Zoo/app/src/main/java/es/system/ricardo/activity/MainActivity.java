package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import es.system.ricardo.R;
import es.system.ricardo.activity.animal.PantallaAnimal;
import es.system.ricardo.activity.especie.PantallaEspecie;
import es.system.ricardo.activity.zoo.PantallaZoo;

public class MainActivity extends AppCompatActivity {
    Button botonZoo;
    Button botonAnimal;
    Button botonEspecie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botonZoo = (Button) findViewById(R.id.idAccionesZoo);
        botonAnimal = (Button) findViewById(R.id.idAccionesAnimal);
        botonEspecie = (Button) findViewById(R.id.idAccionesEspecie);
    }

    public void accionesZoo(View view) {
        Intent cambioZoo = new Intent(MainActivity.this,
                PantallaZoo.class);
        startActivity(cambioZoo);
    }

    public void accionesAnimal(View view) {
        Intent cambioAnimal = new Intent(MainActivity.this,
                PantallaAnimal.class);
        startActivity(cambioAnimal);
    }

    public void accionesEspecie(View view) {
        Intent cambioEspecie = new Intent(MainActivity.this,
                PantallaEspecie.class);
        startActivity(cambioEspecie);
    }
}