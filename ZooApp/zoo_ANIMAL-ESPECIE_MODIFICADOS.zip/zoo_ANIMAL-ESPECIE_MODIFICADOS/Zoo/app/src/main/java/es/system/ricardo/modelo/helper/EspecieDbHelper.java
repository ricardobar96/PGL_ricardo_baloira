package es.system.ricardo.modelo.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.system.ricardo.modelo.contract.EspecieContract;
import es.system.ricardo.modelo.contract.ZooContract;
import es.system.ricardo.vo.Especie;
import es.system.ricardo.vo.Zoo;

public class EspecieDbHelper extends ComunDbHelper {

    public EspecieDbHelper(Context context) {
        super(context);
    }

    /**
     * Metodo encargado en crear la tabla de la BBDD
     * @param sqLiteDatabase BBDD SqLite
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("create table " + EspecieContract.EspecieEntry.nombreTabla + "("
                + EspecieContract.EspecieEntry.id + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + EspecieContract.EspecieEntry.nombreVulgar + " text NOT NULL,"
                + EspecieContract.EspecieEntry.nombreCientifico + " text NOT NULL,"
                + EspecieContract.EspecieEntry.familia + " text NOT NULL,"
                + EspecieContract.EspecieEntry.peligroExtincion + " boolean NOT NULL)");

        // Insertar datos ficticios para prueba inicial
        mockData(sqLiteDatabase);

    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockEspecie(sqLiteDatabase, new Especie(1, "Oso panda",
                "Osos pandus", "Mamiferos", true));
    }

    public long mockEspecie(SQLiteDatabase sqLiteDatabase, Especie especie) {
        return sqLiteDatabase.insert(
                EspecieContract.EspecieEntry.nombreTabla,
                null,
                especie.toContentValues());
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // No hay operaciones
    }

    /**
     * Funcion encargada en realizar el almacenamiento de un usuario
     * @param  especie de la BBDD
     * @return identificador con el resultado en el proceso de almacenar
     * en la BBDD
     */
    public long save(Especie especie) {
        return super.save(EspecieContract.EspecieEntry.nombreTabla,
                especie.toContentValues());
    }

    /**
     * Funcion encargada de retornar todos los elementos de la BBDD
     * @return Lista vacia o todos los elementos de la BBDD
     */
    public List<Especie> getAll() {
        List<Especie> especies = new ArrayList<>();
        Cursor cursor = null;


        try {
            cursor = super.getAll(EspecieContract.EspecieEntry.nombreTabla,
                    null, null, null,
                    null, null, null);

            if(cursor.moveToFirst()){
                especies = new ArrayList<>();
                boolean peligroExtincionBooleano = false;
                do {
                    @SuppressLint("Range") int id = cursor.getInt
                            (cursor.getColumnIndex(EspecieContract.EspecieEntry.id));
                    @SuppressLint("Range") String nombreVulgar = cursor.getString
                            (cursor.getColumnIndex(EspecieContract.EspecieEntry.nombreVulgar));
                    @SuppressLint("Range") String nombreCientifico = cursor.getString
                            (cursor.getColumnIndex(EspecieContract.EspecieEntry.nombreCientifico));
                    @SuppressLint("Range") String familia = cursor.getString
                            (cursor.getColumnIndex(EspecieContract.EspecieEntry.familia));
                    @SuppressLint("Range") int peligroExtincion = cursor.getInt
                            (cursor.getColumnIndex(EspecieContract.EspecieEntry.peligroExtincion));
                    if(peligroExtincion==1){
                        peligroExtincionBooleano = true;
                    }

                    Especie especie = new Especie(id, nombreVulgar, nombreCientifico, familia, peligroExtincionBooleano);
                    especies.add(especie);
                } while (cursor.moveToNext());
                return especies;
            }
        } catch (Exception exception) {
            // TODO: Se debe de implementar las excepciones
        } finally {
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }

        return Collections.emptyList(); //Retornamos una lista vacia
    }

    /**
     * Cursor con el elemento encontrado en la BBDD
     * @param id identificador de consulta de la BBDD
     * @return cursor con el elemento
     */
    public Especie getById(int id) {
        Especie especie = null;
        Cursor cursor = null;
        try {
            cursor = super.getAll(EspecieContract.EspecieEntry.nombreTabla,
                    null,
                    EspecieContract.EspecieEntry.id + " = ?",
                    new String[]{String.valueOf((id))},
                    null,
                    null,
                    null);

            if(cursor.moveToFirst()){
                boolean peligroExtincionBooleano = false;
                @SuppressLint("Range") int idEspecie = cursor.getInt
                        (cursor.getColumnIndex(EspecieContract.EspecieEntry.id));
                @SuppressLint("Range") String nombreVulgar = cursor.getString
                        (cursor.getColumnIndex(EspecieContract.EspecieEntry.nombreVulgar));
                @SuppressLint("Range") String nombreCientifico = cursor.getString
                        (cursor.getColumnIndex(EspecieContract.EspecieEntry.nombreCientifico));
                @SuppressLint("Range") String familia = cursor.getString
                        (cursor.getColumnIndex(EspecieContract.EspecieEntry.familia));
                @SuppressLint("Range") int peligroExtincion = cursor.getInt
                        (cursor.getColumnIndex(EspecieContract.EspecieEntry.peligroExtincion));
                if(peligroExtincion==1){
                    peligroExtincionBooleano = true;
                }
                especie = new Especie(idEspecie, nombreVulgar, nombreCientifico, familia, peligroExtincionBooleano);
            }
        } catch (Exception exception) {
            // TODO: Se debe de implementar el trato de las exception
        }finally {
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }
        return especie;
    }


    /**
     * Funcion encargada en eliminar un elemento de la BBBDD
     * @param id identificador de consulta de la BBDD
     * @return valor con el resultado de la operacion
     */
    public int delete(int id) {
        return super.delete(EspecieContract.EspecieEntry.nombreTabla,
                EspecieContract.EspecieEntry.id + " = ?",
                new String[]{id + ""});
    }

    /**
     * Funcion encargada de realizar la actualizacion de un elemento
     * de la BBDD
     * @param especie de la app
     * @param id relacionado
     * @return entero con el valor de la operacion
     */
    public int update(Especie especie, int id) {
        return super.update(EspecieContract.EspecieEntry.nombreTabla,
                especie.toContentValues(),
                EspecieContract.EspecieEntry.id + " = ?",
                new String[]{String.valueOf(id)});
    }

}
