package es.system.ricardo.modelo.contract;

import android.provider.BaseColumns;

public class AnimalContract {
    public static abstract class AnimalEntry implements BaseColumns {
        public static final String nombreTabla ="animal";
        public static final String id ="idAnimal";
        public static final String idEspecie ="idEspecie";
        public static final String sexo = "sexo";
        public static final String anioNacimiento = "anioNacimiento";
        public static final String pais ="pais";
        public static final String continente = "continente";
    }
}
