package es.system.ricardo.modelo.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.system.ricardo.modelo.contract.EspecieContract;
import es.system.ricardo.vo.Animal;
import es.system.ricardo.modelo.contract.AnimalContract;
import es.system.ricardo.vo.Especie;

public class AnimalDbHelper extends ComunDbHelper {

    public AnimalDbHelper(Context context) {
        super(context);
    }

    /**
     * Metodo encargado en crear la tabla de la BBDD
     * @param sqLiteDatabase BBDD SqLite
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("create table " + AnimalContract.AnimalEntry.nombreTabla + " ("
                + AnimalContract.AnimalEntry.id + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + AnimalContract.AnimalEntry.idEspecie + " INTEGER NOT NULL,"
                + AnimalContract.AnimalEntry.sexo + " text NOT NULL,"
                + AnimalContract.AnimalEntry.anioNacimiento + " INTEGER NOT NULL,"
                + AnimalContract.AnimalEntry.pais + " text NOT NULL,"
                + AnimalContract.AnimalEntry.continente + " text NOT NULL)");

        // Insertar datos ficticios para prueba inicial
        mockData(sqLiteDatabase);

    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockAnimal(sqLiteDatabase, new Animal(5, 15, "Macho", 1999,
                "China", "Asia"));
    }

    public long mockAnimal(SQLiteDatabase sqLiteDatabase, Animal animal) {
        return sqLiteDatabase.insert(
                AnimalContract.AnimalEntry.nombreTabla,
                null,
                animal.toContentValues());
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + AnimalContract.AnimalEntry.nombreTabla );
        onCreate(sqLiteDatabase);
    }

    /**
     * Funcion encargada en realizar el almacenamiento de un usuario
     * @param  animal de la BBDD
     * @return identificador con el resultado en el proceso de almacenar
     * en la BBDD
     */
    public long save(Animal animal) {
        return super.save(AnimalContract.AnimalEntry.nombreTabla,
                animal.toContentValues());
    }

    /**
     * Funcion encargada de retornar todos los elementos de la BBDD
     * @return Lista vacia o todos los elementos de la BBDD
     */
    public List<Animal> getAll() {
        List<Animal> animales = null;
        Cursor cursor = null;


        try {
            cursor = super.getAll(AnimalContract.AnimalEntry.nombreTabla,
                    null, null, null,
                    null, null, null);

            if(cursor.moveToFirst()){
                animales = new ArrayList<>();

                do {
                    @SuppressLint("Range") int id = cursor.getInt
                            (cursor.getColumnIndex(AnimalContract.AnimalEntry.id));
                    @SuppressLint("Range") int idEspecie = cursor.getInt
                            (cursor.getColumnIndex(AnimalContract.AnimalEntry.idEspecie));
                    @SuppressLint("Range") String sexo = cursor.getString
                            (cursor.getColumnIndex(AnimalContract.AnimalEntry.sexo));
                    @SuppressLint("Range") int anioNacimiento = cursor.getInt
                            (cursor.getColumnIndex(AnimalContract.AnimalEntry.anioNacimiento));
                    @SuppressLint("Range") String pais = cursor.getString
                            (cursor.getColumnIndex(AnimalContract.AnimalEntry.pais));
                    @SuppressLint("Range") String continente = cursor.getString
                            (cursor.getColumnIndex(AnimalContract.AnimalEntry.continente));

                    Animal animal = new Animal(id, idEspecie, sexo, anioNacimiento, pais, continente);
                    animales.add(animal);
                } while (cursor.moveToNext());
                return animales;
            }
        } catch (Exception exception) {
            // TODO: Se debe de implementar las excepciones
        } finally {
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }

        return Collections.emptyList(); //Retornamos una lista vacia
    }

    /**
     * Cursor con el elemento encontrado en la BBDD
     * @param id identificador de consulta de la BBDD
     * @return cursor con el elemento
     */
    public Animal getById(int id) {
        Animal animal = null;
        Cursor cursor = null;
        try {
            cursor = super.getAll(AnimalContract.AnimalEntry.nombreTabla,
                    null,
                    AnimalContract.AnimalEntry.id + " = ?",
                    new String[]{String.valueOf((id))},
                    null,
                    null,
                    null);

            if(cursor.moveToFirst()){
                @SuppressLint("Range") int idAnimal = cursor.getInt
                        (cursor.getColumnIndex(AnimalContract.AnimalEntry.id));
                @SuppressLint("Range") int idEspecie = cursor.getInt
                        (cursor.getColumnIndex(AnimalContract.AnimalEntry.idEspecie));
                @SuppressLint("Range") String sexo = cursor.getString
                        (cursor.getColumnIndex(AnimalContract.AnimalEntry.sexo));
                @SuppressLint("Range") int anioNacimiento = cursor.getInt
                        (cursor.getColumnIndex(AnimalContract.AnimalEntry.anioNacimiento));
                @SuppressLint("Range") String pais = cursor.getString
                        (cursor.getColumnIndex(AnimalContract.AnimalEntry.pais));
                @SuppressLint("Range") String continente = cursor.getString
                        (cursor.getColumnIndex(AnimalContract.AnimalEntry.continente));
                animal = new Animal(idAnimal, idEspecie, sexo, anioNacimiento, pais, continente);
            }
        } catch (Exception exception) {
            // TODO: Se debe de implementar el trato de las exception
        }finally {
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }
        return animal;
    }


    /**
     * Funcion encargada en eliminar un elemento de la BBBDD
     * @param id identificador de consulta de la BBDD
     * @return valor con el resultado de la operacion
     */
    public int delete(int id) {
        return super.delete(AnimalContract.AnimalEntry.nombreTabla,
                AnimalContract.AnimalEntry.id + " = ?",
                new String[]{String.valueOf(id)});
    }

    /**
     * Funcion encargada de realizar la actualizacion de un elemento
     * de la BBDD
     * @param animal de la app
     * @param id relacionado
     * @return entero con el valor de la operacion
     */
    public int update(Animal animal, int id) {
        return super.update(AnimalContract.AnimalEntry.nombreTabla,
                animal.toContentValues(),
                AnimalContract.AnimalEntry.id + " = ?",
                new String[]{String.valueOf(id)});
    }

}
