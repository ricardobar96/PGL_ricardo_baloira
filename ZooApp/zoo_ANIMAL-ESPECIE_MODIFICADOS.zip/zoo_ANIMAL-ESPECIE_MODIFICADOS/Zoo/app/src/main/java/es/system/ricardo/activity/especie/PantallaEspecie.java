package es.system.ricardo.activity.especie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import es.system.ricardo.R;
import es.system.ricardo.activity.MainActivity;

public class PantallaEspecie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_especie);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_especie, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.menuCrearEspecie:
                Intent pantallaCrearEspecie =
                        new Intent(PantallaEspecie.this,
                                PantallaCrearEspecie.class);
                startActivity(pantallaCrearEspecie);
                break;
            case R.id.menuBuscarEspecie:
                Intent pantallaBuscarEspecie =
                        new Intent(PantallaEspecie.this,
                                PantallaBuscarEspecie.class);
                startActivity(pantallaBuscarEspecie);
                break;
            case R.id.menuModificarEspecie:
                Intent pantallaModificarEspecie =
                        new Intent(PantallaEspecie.this,
                                PantallaModificarEspecie.class);
                startActivity(pantallaModificarEspecie);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaEspecie.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}