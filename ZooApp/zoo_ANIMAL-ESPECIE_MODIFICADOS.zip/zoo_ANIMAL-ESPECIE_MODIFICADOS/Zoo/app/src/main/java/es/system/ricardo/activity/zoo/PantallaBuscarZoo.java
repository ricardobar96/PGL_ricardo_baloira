package es.system.ricardo.activity.zoo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import es.system.ricardo.R;
import es.system.ricardo.modelo.helper.ZooDbHelper;
import es.system.ricardo.vo.Zoo;

public class PantallaBuscarZoo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_buscar_zoo);
    }

    public void retroceder(View view) {
        Intent retroceder = new Intent(PantallaBuscarZoo.this,
                PantallaZoo.class);
        startActivity(retroceder);
    }

    public void buscarZoo(View view){
        try{
            ZooDbHelper zdb = new ZooDbHelper(view.getContext());
            String nombreBuscar = findViewById(R.id.nombreZooFind).toString();
            Zoo encontrado = zdb.getById(nombreBuscar);

            Toast.makeText(PantallaBuscarZoo.this, "Zoo encontrado: "
//                    + encontrado.getNombre() + " || " +
//                    encontrado.getCiudad() + " || " +
//                    encontrado.getPais() + " || " +
//                    encontrado.getTamanio() + " || " +
//                    encontrado.getPresupuestoAnual()
                    , Toast.LENGTH_SHORT).show();
        }
        catch(Exception ex){
            Toast.makeText(PantallaBuscarZoo.this, "Ha ocurrido un error", Toast.LENGTH_SHORT).show();
        }

    }
}