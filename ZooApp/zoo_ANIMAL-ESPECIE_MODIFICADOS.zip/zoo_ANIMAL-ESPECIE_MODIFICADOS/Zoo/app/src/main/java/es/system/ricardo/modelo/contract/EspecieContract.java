package es.system.ricardo.modelo.contract;

import android.provider.BaseColumns;

public class EspecieContract {
    public static abstract class EspecieEntry implements BaseColumns {
        public static final String nombreTabla ="especie";
        public static final String id = "id";
        public static final String nombreVulgar ="nombreVulgar";
        public static final String nombreCientifico ="nombreCientifico";
        public static final String familia = "familia";
        public static final String peligroExtincion = "peligroExtincion";
    }
}
