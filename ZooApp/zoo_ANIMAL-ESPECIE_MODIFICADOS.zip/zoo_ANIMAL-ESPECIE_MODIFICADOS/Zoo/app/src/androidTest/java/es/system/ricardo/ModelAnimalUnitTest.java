package es.system.ricardo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import es.system.ricardo.modelo.helper.AnimalDbHelper;
import es.system.ricardo.vo.Animal;

public class ModelAnimalUnitTest extends ComunUtilsTest{
    Animal animal;

    @Before
    public void before(){
        animal = new Animal(3, 7, "Macho", 1999, "Brasil",
                "America");
    }

    @Test
    public void findAnimalTest(){
        animalesDbHelper.save(animal);
        Animal animalFind = animalesDbHelper.getById(animal.getId());
        assertNotNull("El animal encontrado es null", animalFind);
        assertEquals("El objeto almacenado y encontrado no son iguales",animalFind, animal);
    }

    @Test
    public void findAnimalesTest(){
        animalesDbHelper.save(animal);
        List<Animal> animales = animalesDbHelper.getAll();
        assertNotNull("El numero de animales encontrado es menor de 1", animales.size() < 1);
        assertEquals("El objeto almacenado y encontrado no son iguales",animales.get(0), animal);
    }

    @Test
    public void saveAnimalTest(){
        assertNotNull("El animal se ha agregado con exito a la tabla",
                animalesDbHelper.save(animal));
    }

    @Test
    public void updateAnimalTest(){
        assertNotEquals("El animal se ha actualizado con exito",
                animal, animalesDbHelper.update(animal, 1));
    }

    @Test
    public void deleteAnimalesTest(){
        animalesDbHelper.save(animal);
        int resultado = animal.getId();
        animalesDbHelper.delete(resultado);
        assertEquals("No se ha podido eliminar el animal", animalesDbHelper.getById(resultado), null);

    }
}
