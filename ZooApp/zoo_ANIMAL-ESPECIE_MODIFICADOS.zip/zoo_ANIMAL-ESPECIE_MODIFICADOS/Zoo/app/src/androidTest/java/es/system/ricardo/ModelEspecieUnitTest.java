package es.system.ricardo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import es.system.ricardo.vo.Especie;

public class ModelEspecieUnitTest extends ComunUtilsTest{
    Especie especie;

    @Before
    public void before(){
        especie = new Especie(2, "Ballena", "Ballenus", "Mamifero",
                true);
    }

    @Test
    public void findEspecieTest(){
        especiesDbHelper.save(especie);
        Especie especieFind = especiesDbHelper.getById(especie.getId());
        assertNotNull("La especie encontrada es null", especieFind);
        assertEquals("El objeto almacenado y encontrado no son iguales",especieFind, especie);
    }

    @Test
    public void findEspeciesTest(){
        List<Especie> especies = especiesDbHelper.getAll();
        assertNotNull("El numero de especies encontrado es menor de 1",
                especies.size() < 1);
        assertEquals("El objeto almacenado y encontrado no son iguales",
                especies.get(0), especie);
    }

    @Test
    public void saveEspecieTest(){
        assertNotNull("La especie se ha agregado con exito a la tabla",
                especiesDbHelper.save(especie));
    }

    @Test
    public void updateEspecieTest(){
        assertNotEquals("La especie se ha actualizado con exito",
                especie, especiesDbHelper.update(especie, 1));
    }

    @Test
    public void deleteEspecieTest(){
        int resultado = especiesDbHelper.delete(1);
        assertTrue(resultado == 1);
    }

    @After
    public void cleanRecordsPerTest(){
        especiesDbHelper.onUpgrade(especiesDbHelper.getWritableDatabase(), 1, 2);
    }
}
