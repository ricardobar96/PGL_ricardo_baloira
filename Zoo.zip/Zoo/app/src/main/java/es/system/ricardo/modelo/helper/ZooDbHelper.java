package es.system.ricardo.modelo.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.system.ricardo.vo.Zoo;
import es.system.ricardo.modelo.contract.ZooContract;

public class ZooDbHelper extends ComunDbHelper {

    public ZooDbHelper(Context context) {
        super(context);
    }

    /**
     * Metodo encargado en crear la tabla de la BBDD
     * @param sqLiteDatabase BBDD SqLite
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("create table " + ZooContract.ZooEntry.nombreTabla + "("
                + ZooContract.ZooEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + ZooContract.ZooEntry.nombre + " text NOT NULL,"
                + ZooContract.ZooEntry.ciudad + " text NOT NULL, "
                + ZooContract.ZooEntry.pais + " text NOT NULL, "
                + ZooContract.ZooEntry.tamanio + " real NOT NULL, "
                + ZooContract.ZooEntry.presupuestoAnual + " real NOT NULL)");


    // Insertar datos ficticios para prueba inicial
    mockData(sqLiteDatabase);

    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockZoo(sqLiteDatabase, new Zoo("Natura World", "Nueva York",
                "EEUU", 12345, 2000000));
    }

    public long mockZoo(SQLiteDatabase sqLiteDatabase, Zoo zoo) {
        return sqLiteDatabase.insert(
                ZooContract.ZooEntry.nombreTabla,
                null,
                zoo.toContentValues());
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // No hay operaciones
    }

    /**
     * Funcion encargada en realizar el almacenamiento de un usuario
     * @param  zoo de la BBDD
     * @return identificador con el resultado en el proceso de almacenar
     * en la BBDD
     */
    public long save(Zoo zoo) {
        return super.save(ZooContract.ZooEntry.nombreTabla,
                zoo.toContentValues());
    }

    /**
     * Funcion encargada de retornar todos los elementos de la BBDD
     * @return Lista vacia o todos los elementos de la BBDD
     */
    public List<Zoo> getAll() {
        List<Zoo> zoos = null;
        Cursor cursor = null;


        try {
            cursor = super.getAll(ZooContract.ZooEntry.nombreTabla,
                    null, null, null,
                    null, null, null);

            if(cursor.moveToFirst()){
                zoos = new ArrayList<>();

                do {
                    @SuppressLint("Range") String nombre = cursor.getString
                            (cursor.getColumnIndex(ZooContract.ZooEntry.nombre));
                    @SuppressLint("Range") String ciudad = cursor.getString
                            (cursor.getColumnIndex(ZooContract.ZooEntry.ciudad));
                    @SuppressLint("Range") String pais = cursor.getString
                            (cursor.getColumnIndex(ZooContract.ZooEntry.pais));
                    @SuppressLint("Range") double tamanio = cursor.getDouble
                            (cursor.getColumnIndex(ZooContract.ZooEntry.tamanio));
                    @SuppressLint("Range") double presupuestoAnual = cursor.getDouble
                            (cursor.getColumnIndex(ZooContract.ZooEntry.presupuestoAnual));

                    Zoo zoo = new Zoo(nombre, ciudad, pais, tamanio, presupuestoAnual);
                    zoos.add(zoo);
                } while (cursor.moveToNext());
                return zoos;
            }
        } catch (Exception exception) {
            // TODO: Se debe de implementar las excepciones
        } finally {
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }

        return Collections.emptyList(); //Retornamos una lista vacia
    }

    /**
     * Cursor con el elemento encontrado en la BBDD
     * @param nombre identificador de consulta de la BBDD
     * @return cursor con el elemento
     */
    public Zoo getById(String nombre) {
        Zoo zoo = null;
        Cursor cursor = null;
        try {
            cursor = super.getAll(ZooContract.ZooEntry.nombreTabla,
                    null,
                    ZooContract.ZooEntry.nombre + " like ?",
                    new String[]{nombre},
                    null,
                    null,
                    null);

            if(cursor.moveToFirst()){

                @SuppressLint("Range") String ciudad = cursor.getString
                        (cursor.getColumnIndex(ZooContract.ZooEntry.ciudad));
                @SuppressLint("Range") String pais = cursor.getString
                        (cursor.getColumnIndex(ZooContract.ZooEntry.pais));
                @SuppressLint("Range") double tamanio = cursor.getDouble
                        (cursor.getColumnIndex(ZooContract.ZooEntry.tamanio));
                @SuppressLint("Range") double presupuestoAnual = cursor.getDouble
                        (cursor.getColumnIndex(ZooContract.ZooEntry.presupuestoAnual));
                zoo = new Zoo(nombre, ciudad, pais, tamanio, presupuestoAnual);
                }
        } catch (Exception exception) {
            // TODO: Se debe de implementar el trato de las exception
        }finally {
            if (!cursor.isClosed()) {
                cursor.close();
            }
        }
        return zoo;
    }


    /**
     * Funcion encargada en eliminar un elemento de la BBBDD
     * @param nombre identificador de consulta de la BBDD
     * @return valor con el resultado de la operacion
     */
    public int delete(String nombre) {
        return super.delete(ZooContract.ZooEntry.nombreTabla,
                ZooContract.ZooEntry.nombre + " like ?",
                new String[]{nombre});
    }

    /**
     * Funcion encargada de realizar la actualizacion de un elemento
     * de la BBDD
     * @param zoo de la app
     * @param nombre relacionado
     * @return entero con el valor de la operacion
     */
    public int update(Zoo zoo, String nombre) {
        return super.update(ZooContract.ZooEntry.nombreTabla,
                zoo.toContentValues(),
                ZooContract.ZooEntry.nombre + " like ?",
                new String[]{nombre});
    }

}
