package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.system.ricardo.R;

public class PantallaZoo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_zoo);
    }

    public void crearZoo(View view) {
        Intent pantallaCrearZoo = new Intent(PantallaZoo.this,
                PantallaCrearZoo.class);
        startActivity(pantallaCrearZoo);
    }

    public void modificarZoo(View view) {
        Intent pantallaModificarZoo = new Intent(PantallaZoo.this,
                PantallaModificarZoo.class);
        startActivity(pantallaModificarZoo);
    }

    public void buscarZoo(View view) {
        Intent pantallaBuscarZoo = new Intent(PantallaZoo.this,
                PantallaBuscarZoo.class);
        startActivity(pantallaBuscarZoo);
    }

    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaZoo.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}