package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.system.ricardo.R;

public class PantallaAnimal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_animal);
    }

    public void crearAnimal(View view) {
        Intent pantallaCrearAnimal = new Intent(PantallaAnimal.this,
                PantallaCrearAnimal.class);
        startActivity(pantallaCrearAnimal);
    }

    public void modificarAnimal(View view) {
        Intent pantallaModificarAnimal = new Intent(PantallaAnimal.this,
                PantallaModificarAnimal.class);
        startActivity(pantallaModificarAnimal);
    }

    public void buscarAnimal(View view) {
        Intent pantallaBuscarAnimal = new Intent(PantallaAnimal.this,
                PantallaBuscarAnimal.class);
        startActivity(pantallaBuscarAnimal);
    }

    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaAnimal.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}