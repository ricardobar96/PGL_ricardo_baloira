package es.system.ricardo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.system.ricardo.R;

public class PantallaEspecie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_especie);
    }

    public void crearEspecie(View view) {
        Intent pantallaCrearEspecie = new Intent(PantallaEspecie.this,
                PantallaCrearEspecie.class);
        startActivity(pantallaCrearEspecie);
    }

    public void modificarEspecie(View view) {
        Intent pantallaModificarEspecie = new Intent(PantallaEspecie.this,
                PantallaModificarEspecie.class);
        startActivity(pantallaModificarEspecie);
    }

    public void buscarEspecie(View view) {
        Intent pantallaBuscarEspecie = new Intent(PantallaEspecie.this,
                PantallaBuscarEspecie.class);
        startActivity(pantallaBuscarEspecie);
    }

    public void menuPrincipal(View view) {
        Intent regresarMenu = new Intent(PantallaEspecie.this,
                MainActivity.class);
        startActivity(regresarMenu);
    }
}